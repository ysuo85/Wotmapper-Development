mpackage = "wotmapper_with_doors"
